const assert = require('node:assert/strict');
const Module = require('node:module');
const path = require('node:path');
const test = require('node:test');

const nativePath = require.resolve('../lib/native-flow-menu');
const nativeStub = new Module(nativePath);
const nativeCalls = [];
nativeStub.exports = {
  sendNativeMenu: async (_sock, _jid, options) => { nativeCalls.push(options); },
  mainRows: () => [],
  buildFallbackMenu: () => 'MENU FALLBACK UJI',
};
nativeStub.loaded = true;
require.cache[nativePath] = nativeStub;

const menu = require('../plugins/menu/menu');
const baseConfig = require('../config');
const from = 'test@g.us';

function makeContext(mode, overrides = {}) {
  return {
    config: {
      ...baseConfig,
      sendMenuAs: mode,
      menuImageUrl: 'https://example.invalid/menu.png',
      voiceMenuUrl: '',
      menuVoiceEnabled: false,
      ...overrides,
    },
    from,
    user: { limit: 10, money: 100, point: 0, exp: 0, registered: true },
    pushName: 'Pengguna Uji',
    sender: '628123456789@s.whatsapp.net',
    isSenderOwner: () => false,
    isPremium: () => false,
    loadDB: () => ({}),
  };
}

function makeSocket({ rejectRemoteImage = false } = {}) {
  const messages = [];
  const sock = {
    async sendMessage(_jid, message) {
      if (rejectRemoteImage && message.image?.url === 'https://example.invalid/menu.png') {
        throw new Error('Simulasi URL gambar tidak dapat diakses');
      }
      messages.push(message);
    },
  };
  return { sock, messages };
}

test('menu text mode sends text rather than interactive content', async () => {
  const { sock, messages } = makeSocket();
  await menu.execute(sock, {}, [], makeContext('text'));
  assert.equal(messages.length, 1);
  assert.equal(typeof messages[0].text, 'string');
  assert.match(messages[0].text, /MENU UTAMA/);
  assert.equal(messages[0].image, undefined);
});

test('menu image mode tries the local bundled logo when custom image fails', async () => {
  const { sock, messages } = makeSocket({ rejectRemoteImage: true });
  await menu.execute(sock, {}, [], makeContext('image'));
  assert.equal(messages.length, 1);
  assert.ok(messages[0].image.url.endsWith(path.join('assets', 'logo.jpg')));
  assert.equal(typeof messages[0].caption, 'string');
});

test('menu both mode sends the image path without waiting on voice when voice URL is absent', async () => {
  const { sock, messages } = makeSocket();
  await menu.execute(sock, {}, [], makeContext('both'));
  assert.equal(messages.length, 1);
  assert.ok(messages[0].image);
  assert.equal(messages[0].audio, undefined);
});

test('menu voice mode falls back to text if no voice URL is configured', async () => {
  const { sock, messages } = makeSocket();
  await menu.execute(sock, {}, [], makeContext('voice'));
  assert.equal(messages.length, 1);
  assert.equal(typeof messages[0].text, 'string');
});

test('menu native mode delegates to the interactive menu builder', async () => {
  nativeCalls.length = 0;
  const { sock } = makeSocket();
  await menu.execute(sock, {}, [], makeContext('native'));
  assert.equal(nativeCalls.length, 1);
  assert.match(nativeCalls[0].footer, /OBSIDIAN LUXE/);
  assert.match(nativeCalls[0].title, /v8\.0\.0/);
});
