const fs = require('fs');
const path = require('path');
const { spawnSync } = require('node:child_process');
const { VERSION } = require('../lib/version');

const root = path.join(__dirname, '..');
const pkg = require(path.join(root, 'package.json'));
const required = Object.keys(pkg.dependencies || {});
const failures = [];

for (const dependency of required) {
  try { require.resolve(dependency, { paths: [root] }); }
  catch { failures.push(`dependency belum tersedia: ${dependency}`); }
}

const pluginRoot = path.join(root, 'plugins');
let pluginFiles = 0;
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile() && (entry.name.endsWith('.js') || entry.name.endsWith('.mjs'))) pluginFiles++;
  }
}
walk(pluginRoot);

const ffmpeg = spawnSync(process.env.FFMPEG_PATH || 'ffmpeg', ['-version'], { stdio: 'ignore' }).status === 0;
if (!ffmpeg) failures.push('FFmpeg tidak tersedia di PATH/FFMPEG_PATH');

console.log(`YORA BOTZ v${VERSION} PREFLIGHT`);
console.log(`Plugins: ${pluginFiles}`);
console.log(`Node: ${process.version}`);
console.log(`FFmpeg: ${ffmpeg ? 'OK' : 'MISSING'}`);
if (failures.length) {
  console.error('\nATTENTION:');
  for (const failure of failures) console.error(`- ${failure}`);
  console.error('\nJalankan npm install sebelum deployment.');
  process.exitCode = 1;
} else {
  console.log('All runtime dependencies are available.');
}
