const {
  sendNativeMenu,
  categoryRows,
  buildFallbackMenu,
} = require('../../lib/native-flow-menu');

module.exports = {
  name: 'menupicker',
  category: 'menu',
  aliases: ['menukategori', 'menucategory', 'pickmenu'],
  async execute(sock, msg, args, ctx) {
    const { config, from } = ctx;
    const prefix = config.prefix || '.';
    const isOwner = Boolean(ctx.isSenderOwner && ctx.isSenderOwner());
    const rows = categoryRows(prefix, isOwner);

    try {
      await sendNativeMenu(sock, from, {
        title: '✦ YORA BOTZ · KATEGORI',
        body: 'Pilih kategori untuk membuka menu yang kamu butuhkan.',
        footer: 'YORA BOTZ · Pilih Kategori',
        rows,
        quoted: msg,
      });
    } catch (error) {
      console.warn('⚠️ Native Flow kategori gagal, memakai fallback:', error.message);
      const fallback = buildFallbackMenu(from, prefix, isOwner);
      await sock.sendMessage(from, { text: fallback }, { quoted: msg });
    }
  },
};
